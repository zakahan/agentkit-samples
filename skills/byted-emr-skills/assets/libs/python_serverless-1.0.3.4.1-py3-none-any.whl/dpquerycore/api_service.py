import json
import re
import threading
import time
import urllib
from abc import ABC
from collections import OrderedDict
from typing import Dict, Type, List, Optional
from datetime import datetime, timedelta

import requests
from dpquerycore import VERSION
from volcengine.ApiInfo import ApiInfo
from volcengine.Credentials import Credentials as VolcCredentials
from volcengine.ServiceInfo import ServiceInfo
from volcengine.base.Request import Request

from dpquerycore.annotations import deprecated
from dpquerycore.auth import Credentials as ClientCredentials, Identity, \
    TemporaryCredentials
from dpquerycore.consts import Constants
from dpquerycore.exceptions import QuerySdkError
from dpquerycore.protocol import T, CreateQueryResponse, CancelQueryResponse, \
    QueryGetJobV2Response, QueryExplainQueryResponse, DescribeExplainQueryResponse, FetchResultsByBatchResponse, \
    GetResultSchemaResponse, GetTrackingURLResponse, GetResultUrlResponse, \
    QueryGetJobV2Result, QueryExplainQueryResult, DescribeExplainQueryResult, CheckJobStatusResponse, BaseProtocol, \
    LogResponse, LogResult, ListJob, ListJobResponse
from dpquerycore.utils import validate_and_parse_response, retry_top_api
from dpquerycore.volcengine_auth import CustomSignerV4

try:
    from urllib.parse import urlencode
except ImportError:
    from urllib import urlencode

RESULT_URL_PATTERN = re.compile(Constants.REGEX_RESULT_URL)


class _TopService(object):
    _instance_lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        if not hasattr(_TopService, "_instance"):
            with _TopService._instance_lock:
                if not hasattr(_TopService, "_instance"):
                    _TopService._instance = object.__new__(cls)
        return _TopService._instance

    def __init__(self, service_info: ServiceInfo):
        assert service_info is not None
        assert service_info.host is not None and service_info.scheme
        assert service_info.credentials is not None
        assert service_info.credentials.service is not None \
               and service_info.credentials.region is not None
        self.service_info = service_info

        # connection pool
        _session = requests.Session()
        _adapter = requests.adapters.HTTPAdapter(
            pool_connections=Constants.CONNECTION_POOL_CACHE_SIZE,
            pool_maxsize=Constants.CONNECTION_POOL_MAXIMUM_SIZE)
        _session.mount("https://", _adapter)
        _session.mount("http://", _adapter)
        self.session = _session

    def set_host(self, host: str):
        self.service_info.host = host

    def set_scheme(self, scheme: str):
        self.service_info.scheme = scheme

    @property
    def scheme(self):
        return self.service_info.scheme

    @property
    def host(self):
        return self.service_info.host

    @property
    def service(self):
        return self.service_info.credentials.service

    @property
    def region(self):
        return self.service_info.credentials.region

    def get_sign_url(self, api_info: ApiInfo, params: dict,
            credentials: ClientCredentials, identity: Identity):
        mquery = self.merge(api_info.query, params)
        mquery = _TopService.merge(mquery,
            {'identityId': identity.identity_id,
                'identityType': identity.identity_type}) if isinstance(
            credentials, TemporaryCredentials) else mquery
        r = Request()
        r.set_shema(self.service_info.scheme)
        r.set_method(api_info.method)
        r.set_path(api_info.path)
        r.set_query(mquery)

        return CustomSignerV4.sign_url(r, credentials, self.service, self.region)

    def get(self, api_info: ApiInfo, params: dict, credentials: ClientCredentials,
            identity: Identity, doseq: int = 0):
        r = self.prepare_request(
            api_info, params, credentials, identity, doseq)

        CustomSignerV4.sign(r, credentials, self.service, self.region)

        url = r.build(doseq)

        def do_get():
            resp = self.session.get(url, headers=r.headers,
                timeout=(self.service_info.connection_timeout,
                self.service_info.socket_timeout))
            if 200 <= resp.status_code < 300:
                return resp.text
            elif resp.status_code == 403:
                raise QuerySdkError('PermissionDenied', resp.text)
            elif resp.status_code == 404:
                raise QuerySdkError('ResourceNotFound', resp.text)
            else:
                raise QuerySdkError('UnknownError', 'code: %s, resp: %s' % (resp.status_code, resp.text))
        return retry_top_api(do_get)

    def post(self, api_info: ApiInfo, params: dict,
            form: dict, credentials: ClientCredentials, identity: Identity):
        r = self.prepare_request(api_info, params, credentials, identity)
        r.headers['Content-Type'] = 'application/x-www-form-urlencoded'
        r.form = self.merge(api_info.form, form)
        r.body = urlencode(r.form, True)
        CustomSignerV4.sign(r, credentials, self.service, self.region)

        url = r.build()

        resp = self.session.post(url, headers=r.headers, data=r.form,
            timeout=(self.service_info.connection_timeout,
            self.service_info.socket_timeout))
        if 200 <= resp.status_code < 300:
            return resp.text
        elif resp.status_code == 403:
            raise QuerySdkError('PermissionDenied', resp.text)
        elif resp.status_code == 404:
            raise QuerySdkError('ResourceNotFound', resp.text)
        else:
            raise QuerySdkError('UnknownError', 'code: %s, resp: %s' % (resp.status_code, resp.text))

    def json(self, api_info: ApiInfo, params: dict,
            body: str, credentials: ClientCredentials, identity: Identity):
        r = self.prepare_request(api_info, params, credentials, identity)
        r.headers['Content-Type'] = 'application/json'
        r.body = body

        CustomSignerV4.sign(r, credentials, self.service, self.region)

        url = r.build()
        resp = self.session.post(url, headers=r.headers, data=r.body,
            timeout=(self.service_info.connection_timeout,
            self.service_info.socket_timeout))
        if 200 <= resp.status_code < 300:
            return json.dumps(resp.json())
        elif resp.status_code == 403:
            raise QuerySdkError('PermissionDenied', resp.text)
        elif resp.status_code == 404:
            raise QuerySdkError('ResourceNotFound', resp.text)
        else:
            raise QuerySdkError('UnknownError', 'code: %s, resp: %s' % (resp.status_code, resp.text.encode("utf-8")))

    def put(self, url, file_path, headers):
        with open(file_path, 'rb') as f:
            resp = self.session.put(url, headers=headers, data=f)
            if 200 <= resp.status_code < 300:
                return True, resp.text.encode("utf-8")
            elif resp.status_code == 403:
                raise QuerySdkError('PermissionDenied', resp.text)
            elif resp.status_code == 404:
                raise QuerySdkError('ResourceNotFound', resp.text)
            else:
                return False, resp.text.encode("utf-8")

    def put_data(self, url, data, headers):
        resp = self.session.put(url, headers=headers, data=data)
        if 200 <= resp.status_code < 300:
            return True, resp.text.encode("utf-8")
        elif resp.status_code == 403:
            raise QuerySdkError('PermissionDenied', resp.text)
        elif resp.status_code == 404:
            raise QuerySdkError('ResourceNotFound', resp.text)
        else:
            return False, resp.text.encode("utf-8")

    def json_raw(self, api_info: ApiInfo,
            params: dict, body: str, credentials: ClientCredentials,
            identity: Identity):
        r = self.prepare_request(api_info, params, credentials, identity)
        r.headers['Content-Type'] = 'application/json'
        r.body = body

        CustomSignerV4.sign(r, credentials, self.service, self.region)

        url = r.build()

        def do_post() -> str:
            resp = self.session.post(url, headers=r.headers, data=r.body,
                    timeout=(self.service_info.connection_timeout,
                    self.service_info.socket_timeout))
            if 200 <= resp.status_code < 300:
                return resp.text
            elif resp.status_code == 403:
                raise QuerySdkError('PermissionDenied', resp.text)
            elif resp.status_code == 404:
                raise QuerySdkError('ResourceNotFound', resp.text)
            else:
                raise QuerySdkError('UnknownError', 'code: %s, resp: %s' % (resp.status_code, resp.text))
        return retry_top_api(do_post)


    def get_binary(self, api_info: ApiInfo,
            params: dict, credentials: ClientCredentials,
            identity: Identity, doseq: int = 0):
        r = self.prepare_request(
            api_info, params, credentials, identity, doseq)

        CustomSignerV4.sign(r, credentials, self.service, self.region)

        url = r.build(doseq)
        resp = self.session.get(url, headers=r.headers,
            timeout=(self.service_info.connection_timeout,
            self.service_info.socket_timeout))
        if 200 <= resp.status_code < 300:
            return resp.content
        elif resp.status_code == 403:
            raise QuerySdkError('PermissionDenied', resp.text)
        elif resp.status_code == 404:
            raise QuerySdkError('ResourceNotFound', resp.text)
        else:
            raise QuerySdkError('UnknownError', 'code: %s, resp: %s' % (resp.status_code, resp.text))

    def prepare_request(self, api_info: ApiInfo, params: dict,
            credentials: ClientCredentials,
            identity: Identity, doseq: int = 0):
        assert not (
            isinstance(credentials, TemporaryCredentials) and identity is None
        ), 'Identity must be set for temporary credentials'

        for key in params:
            if isinstance(params[key], (int, float, bool)):
                params[key] = str(params[key])
            elif isinstance(params[key], list):
                if not doseq:
                    params[key] = ','.join(params[key])

        connection_timeout = self.service_info.connection_timeout
        socket_timeout = self.service_info.socket_timeout

        r = Request()
        r.set_shema(self.service_info.scheme)
        r.set_method(api_info.method)
        r.set_connection_timeout(connection_timeout)
        r.set_socket_timeout(socket_timeout)

        mheaders = _TopService.merge(api_info.header,
            self.service_info.header)
        mheaders = _TopService.merge(mheaders,
            {
                'X-Top-User-Id': identity.identity_id,
                'X-Security-Token': credentials.sts_token,
                'X-Identity-Id': identity.identity_id
            }
        ) if isinstance(credentials, TemporaryCredentials) else mheaders
        mheaders['Host'] = self.service_info.host
        mheaders['User-Agent'] = 'volc-sdk-python/' + VERSION
        r.set_headers(mheaders)

        mquery = _TopService.merge(api_info.query, params)
        mquery = _TopService.merge(mquery,
            {'identityId': identity.identity_id,
                'identityType': identity.identity_type_str}) if isinstance(
            credentials, TemporaryCredentials) else mquery
        r.set_query(mquery)

        r.set_host(self.service_info.host)
        r.set_path(api_info.path)

        return r

    def close(self):
        self.session.close()

    @staticmethod
    def merge(param1: dict, param2: dict):
        od = OrderedDict()
        for key in param1:
            od[key] = param1[key]

        for key in param2:
            od[key] = param2[key]

        return od

    @staticmethod
    def to_rfc3339(t):
        format_time = time.strftime('%Y-%m-%dT%H:%M:%S%z', time.localtime(t))
        pos = format_time.find('+')
        if pos == -1:
            pos = format_time.find('-')
        return format_time[:pos + 3] + ':' + format_time[pos + 3:pos + 5]


class ApiService(ABC):
    def __init__(self, api_dict: Dict[str, ApiInfo],
            endpoint: str = Constants.TOP_ENDPOINT,
            service: str = Constants.SERVICE_LAS,
            region: str = Constants.REGION_CN_BEIJING,
            scheme: str = 'https',
            connection_timeout: int = Constants.CONNECTION_TIMEOUT,
            socket_timeout: int = Constants.SOCKET_TIMEOUT):
        _parsed_uri = urllib.parse.urlsplit(endpoint)
        self._scheme = _parsed_uri.scheme if _parsed_uri.scheme else scheme
        self._endpoint = _parsed_uri.netloc + _parsed_uri.path
        self._region = region
        self._service_info = ApiService.get_service_info(self._endpoint,
            self._region,
            service,
            scheme=self._scheme,
            connection_timeout=connection_timeout,
            socket_timeout=socket_timeout)
        self._api_info = api_dict
        self._api_service = _TopService(self._service_info)

    @property
    def endpoint(self):
        return self._endpoint

    @property
    def region(self):
        return self._region

    @property
    def scheme(self):
        return self._scheme

    @staticmethod
    def get_service_info(endpoint: str, region: str, service: str,
            scheme: str = 'https',
            connection_timeout: int = Constants.CONNECTION_TIMEOUT,
            socket_timeout: int = Constants.SOCKET_TIMEOUT):
        service_info = ServiceInfo(endpoint,
            {'Accept': 'application/json',
                'x-tqs-appid': Constants.TQS_DEFAULT_APP_ID},
            VolcCredentials('', '', service, region),
            connection_timeout,
            socket_timeout,
            scheme=scheme)
        return service_info

    def get_job(self, job_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_job(credentials, identity, job_id)

        return wrapper

    def _get_job(self, credentials: ClientCredentials, identity: Identity,
            job_id: str) -> QueryGetJobV2Result:
        _api = self._get_api('QueryGetJobV2')
        _res = self._api_service.get(_api, {'Id': job_id}, credentials,
            identity)
        return self._validate_and_parse_response(_api, _res, QueryGetJobV2Response).Result

    def create_query(self, name: str, query: str, conf: dict, **kwargs):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._create_query(credentials, identity, name, query, conf,
                **kwargs)

        return wrapper

    def _create_query(self, credentials: ClientCredentials, identity: Identity,
            name: str, query: str,
            conf: dict, **kwargs) -> str:
        _api = self._get_api('QueryCreateQuery')
        _body = {
            'name': name,
            'query': query,
            'conf': json.dumps(conf),
            'skipDispatch': kwargs.get('skipDispatch', False),
            'user': kwargs.get("user", Constants.LAS_SDK_USER)
        }

        if 'jobId' in kwargs:
            _body['jobId'] = int(kwargs['jobId'])

        _res = self._api_service.json_raw(_api, {},
            json.dumps(_body), credentials,
            identity)
        _job_id = self._validate_and_parse_response(_api, _res, CreateQueryResponse).jobId
        return str(_job_id)

    def cancel_query(self, job_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._cancel_query(credentials, identity, job_id)

        return wrapper

    def _cancel_query(self, credentials: ClientCredentials, identity: Identity,
            job_id: str) -> bool:
        _api = self._get_api('QueryCancelQueryV2')
        _res = self._api_service.json_raw(_api, {'Id': str(job_id)},
            '{}', credentials, identity)
        return self._validate_and_parse_response(_api, _res, CancelQueryResponse).Result.Success

    def analyze_query(self, sql: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._analyze_query(credentials, identity, sql)

        return wrapper

    def _analyze_query(self, credentials: ClientCredentials, identity: Identity,
            sql: str) -> QueryExplainQueryResult:
        _api = self._get_api('QueryExplainQuery')
        _body = {
            'User': Constants.LAS_SDK_USER,
            'Query': sql
        }
        _res = self._api_service.json_raw(_api, {},
            json.dumps(_body), credentials,
            identity)
        return self._validate_and_parse_response(_api, _res, QueryExplainQueryResponse).Result

    def describe_analyze_query(self, analyze_task_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._describe_analyze_query(credentials, identity, analyze_task_id)

        return wrapper

    def _describe_analyze_query(self, credentials: ClientCredentials, identity: Identity,
            analyze_task_id: str) -> DescribeExplainQueryResult:
        _api = self._get_api('QueryDescribeExplainQuery')
        _res = self._api_service.get(_api, {'AnalyzeTaskId': analyze_task_id},
            credentials, identity)
        return self._validate_and_parse_response(_api, _res, DescribeExplainQueryResponse).Result

    @deprecated('Download results directly through the api gateway is not recommended')
    def get_query_result(self, job_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_query_result(credentials, identity, job_id)

        return wrapper

    def _get_query_result(self, credentials: ClientCredentials,
            identity: Identity,
            job_id: str):
        _api = self._get_api('QueryGetQueryResult')
        return self._api_service.get(_api, {'taskId': job_id}, credentials, identity)

    @deprecated('Download results directly through the api gateway is not recommended')
    def download_results(self, url: str, offset: int, limit: int):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._download_results(credentials, identity, url, offset,
                limit)

        return wrapper

    def _download_results(self, credentials: ClientCredentials,
            identity: Identity,
            url: str,
            offset: int,
            limit: int):
        _api = self._get_api('QueryDownloadResults')
        _params = self._parse_params_from_result_url(url)
        _params.update({
            'offset': offset,
            'limit': limit,
        })

        return self._api_service.get_binary(_api, _params, credentials,
            identity)

    def fetch_results_by_batch(self, job_id: str, position: int, limit: int,
            skip_lines: int = 0):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._fetch_results_by_batch(credentials, identity, job_id,
                position, limit, skip_lines)

        return wrapper

    def _fetch_results_by_batch(self, credentials: ClientCredentials,
            identity: Identity,
            job_id: str, position: int, limit: int,
            skip_lines: int) -> FetchResultsByBatchResponse:
        assert job_id.isnumeric(), 'Invalid job id'
        assert position >= 0 and limit > 0 and skip_lines >= 0, \
            'Params are required to be non-negative'
        _api = self._get_api('QueryFetchResultsByBatch')
        _params = {'taskId': job_id, 'position': position,
            'limit': limit, 'skipLines': skip_lines}
        _res = self._api_service.get(_api, _params, credentials, identity)
        return self._validate_and_parse_response(_api, _res, FetchResultsByBatchResponse)

    def get_result_schema(self, job_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_result_schema(credentials, identity, job_id)

        return wrapper

    def _get_result_schema(self, credentials: ClientCredentials,
            identity: Identity, job_id: str) -> List[List[str]]:
        assert job_id.isnumeric(), 'Invalid job id'
        _api = self._get_api('QueryGetResultSchema')
        _res = self._api_service.get(
            _api, {'Id': job_id}, credentials, identity)
        return self._validate_and_parse_response(_api, _res, GetResultSchemaResponse).Result

    def get_tracking_url(self, job_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_tracking_url(credentials, identity, job_id)

        return wrapper

    def _get_tracking_url(self, credentials: ClientCredentials,
            identity: Identity, job_id: str) -> str:
        assert job_id.isnumeric(), 'Invalid job id'
        _api = self._get_api('QueryGetTrackingURL')
        _res = self._api_service.get(
            _api, {'Id': job_id}, credentials, identity)
        return self._validate_and_parse_response(_api, _res, GetTrackingURLResponse).Result

    def get_result_url(self, job_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_result_url(credentials, identity, job_id)

        return wrapper

    def _get_result_url(self, credentials: ClientCredentials,
            identity: Identity, job_id: str) -> str:
        assert job_id.isnumeric(), 'Invalid job id'
        _api = self._get_api('QueryGetResultUrl')
        _res = self._api_service.get(
            _api, {'Id': job_id}, credentials, identity)
        return self._validate_and_parse_response(_api, _res, GetResultUrlResponse).Result

    def _get_api(self, action: str):
        if action not in self._api_info:
            raise ValueError(
                'Invalid action, please check. action = %s' % action)
        return self._api_info.get(action)

    def _parse_params_from_result_url(self, url: str) -> dict:
        matched_groups = RESULT_URL_PATTERN.match(url)
        if matched_groups is None:
            raise ValueError('Illegal result url. resultUrl = %s.' % url)

        _params = {
            'date': matched_groups.group(1),
            'hour': matched_groups.group(2),
            'workerPodName': matched_groups.group(3),
            'fileName': matched_groups.group(4),
        }

        return _params

    def get_error_info(self, job_id: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_error_info(credentials, identity, job_id)

        return wrapper

    def _get_error_info(self, credentials: ClientCredentials,
            identity: Identity, job_id: str) -> Optional[str]:
        assert job_id.isnumeric(), 'Invalid job id'
        _api = self._get_api('QueryCheckJobStatus')
        _res = self._api_service.get(
            _api, {'Id': job_id}, credentials, identity)
        return self._validate_and_parse_response(_api, _res, CheckJobStatusResponse).Result.Error

    def close(self):
        self._api_service.close()

    def get_submission_log(self, job_id: str, position: str, limit: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_submission_log(credentials, identity, job_id, position, limit)

        return wrapper

    def _get_submission_log(self, credentials: ClientCredentials, identity: Identity,
            job_id: str, position: str, limit: str) -> LogResult:
        _api = self._get_api('QueryFetchSubmitLog')
        _res = self._api_service.get(_api, {'Id': str(job_id), 'Position': str(position), 'Limit': str(limit)},
            credentials, identity)
        return self._validate_and_parse_response(_api, _res, LogResponse).Result

    def get_driver_log(self, job_id: str, position: str, limit: str):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._get_driver_log(credentials, identity, job_id, position, limit)

        return wrapper

    def _get_driver_log(self, credentials: ClientCredentials, identity: Identity,
            job_id: str, position: str, limit: str) -> LogResult:
        _api = self._get_api('QueryFetchDriverLog')
        _res = self._api_service.get(_api, {'Id': str(job_id), 'Position': str(position), 'Limit': str(limit)},
            credentials, identity)
        return self._validate_and_parse_response(_api, _res, LogResponse).Result

    def list_job(self, job_id: str, job_name: str,
        start_time: str = "", end_time: str = "",
        queue: str = "",
        limit: int = 20, offset: int = 0):
        def wrapper(credentials: ClientCredentials, identity: Identity = None):
            return self._list_job(credentials, identity,
                job_id, job_name, start_time, end_time,
                queue, limit, offset)

        return wrapper

    def _list_job(self, credentials: ClientCredentials, identity: Identity,
        job_id: str, job_name: str,
        start_time: str = "", end_time: str = "",
        queue: str = "",
        limit: int = 20, offset: int = 0) -> ListJob:
        _api = self._get_api('ListJob')
        params = {'Limit': limit, 'Offset': offset}
        if job_id:
            params['MatchId'] = job_id
        if job_name:
            params['MatchNameExact'] = job_name
        if limit > 100:
            raise QuerySdkError('InvalidParams',
                                "Only support limit less than 100")
        if not start_time:
            start_time = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
        params['StartTime'] = start_time
        if end_time:
            params['EndTime'] = end_time
        if queue:
            params['Queue'] = queue
        params['FROM_SDK'] = True
        _res = self._api_service.get(_api, params, credentials, identity)
        return self._validate_and_parse_response(
            _api, _res, ListJobResponse).Result

    @staticmethod
    def _validate_and_parse_response(api_info: ApiInfo, resp: str,
            cls: Type[T]) -> T:
        if resp is None or resp == '' or resp == 'None':
            raise QuerySdkError('ServerInternalError',
                'Failed to call api [%s] due to some unexpected '
                'reason. Please contact admin.' % api_info.query
            )
        if '"Error"' in resp:
            validate_and_parse_response(resp, BaseProtocol)
        return validate_and_parse_response(resp, cls)

    @staticmethod
    def _help_check_result(response: str, result):
        if result is None:
            raise QuerySdkError('UnknownError',
                'Got unexpected response [%s] from the server. Please retry or contact us for further help.' % response)
        return result

