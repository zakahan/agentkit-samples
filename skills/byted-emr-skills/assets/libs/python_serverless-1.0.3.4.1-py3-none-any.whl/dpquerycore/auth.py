from abc import ABC, abstractmethod

from dpquerycore.enums import IdentityType


class Credentials(ABC):
    @property
    @abstractmethod
    def ak(self) -> str:
        raise NotImplementedError("Not Implemented yet")

    @property
    @abstractmethod
    def sk(self) -> str:
        raise NotImplementedError("Not Implemented yet")


class StaticCredentials(Credentials):
    __slots__ = '_access_key_id', '_access_key_secret'

    def __init__(self, access_key_id: str, access_key_secret: str):
        self._access_key_id = access_key_id
        self._access_key_secret = access_key_secret

    @property
    def ak(self) -> str:
        return self._access_key_id

    @property
    def sk(self) -> str:
        return self._access_key_secret


class TemporaryCredentials(Credentials):
    __slots__ = '_access_key_id', '_access_key_secret', '_sts_token'

    def __init__(self, access_key_id: str, access_key_secret: str,
                 sts_token: str):
        self._access_key_id = access_key_id
        self._access_key_secret = access_key_secret
        self._sts_token = sts_token

        self._expired_time = None

    @property
    def ak(self) -> str:
        return self._access_key_id

    @property
    def sk(self) -> str:
        return self._access_key_secret

    @property
    def sts_token(self) -> str:
        return self._sts_token

    @property
    def expired_time(self) -> int:
        return self._expired_time

    @expired_time.setter
    def expired_time(self, value):
        self._expired_time = value


# TODO future support
# class TokenProvider(ABC):
#     def __init__(self, access_key_id: str, access_key_secret: str, ttl: int = 1 * HOUR):
#         self._access_key_id = access_key_id
#         self._access_key_secret = access_key_secret
#         self._token = None
#         self._created_tm = None
#         self._ttl = ttl
#
#     @abstractmethod
#     def acquire_token(self) -> StaticCredentials:
#         pass
#
#     def get_or_refresh_token(self) -> StaticCredentials:
#         if self._token is None or self._created_tm is None
#           or time.time() >= self._created_tm + self._ttl:
#             _created_tm = time.time()
#             _token = self.acquire_token()
#             self._created_tm = _created_tm
#             self._token = _token
#
#         return self._token
#
#
# class DynamicTokenCredentials(Credentials):
#     __slots__ = '_access_key_id', '_access_key_secret', '_token_provider'
#
#     def __init__(self, access_key_id: str,
#       access_key_secret: str,
#       token_provider: TokenProvider):
#         self._access_key_id = access_key_id
#         self._access_key_secret = access_key_secret
#         self._token_provider = token_provider
#
#     @property
#     def ak(self) -> str:
#         return self._token_provider.get_or_refresh_token().ak
#
#     @property
#     def sk(self) -> str:
#         return self._token_provider.get_or_refresh_token().sk
#
#     @property
#     def sts_token(self) -> str:
#         return self._token_provider.get_or_refresh_token().sts_token


class Identity(ABC):
    def __init__(self, account_id: str, identity_id: str):
        assert account_id.isnumeric(), \
            'Account id & identity id must be an number'
        self._account_id = account_id
        self._identity_id = identity_id
        self._identity_type = IdentityType.Account if account_id == identity_id \
            else IdentityType.User

    @property
    def account_id(self):
        return self._account_id

    @property
    def identity_id(self):
        return self._identity_id

    @property
    def identity_type(self) -> IdentityType:
        return self._identity_type

    @property
    def identity_type_str(self) -> str:
        return str(self.identity_type.name)


class AccountIdentity(Identity):
    def __init__(self, account_id: str):
        super().__init__(account_id, account_id)


class UserIdentity(Identity):
    def __init__(self, account_id: str, identity_id: str):
        super().__init__(account_id, identity_id)
