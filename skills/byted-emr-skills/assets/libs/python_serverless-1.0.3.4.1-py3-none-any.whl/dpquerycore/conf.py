# -*- coding: utf-8 -*-

class TaskConf:
    ENGINE_TYPE = 'tqs.query.engine.type'
    EXECUTE_QUEUE = 'las.execute.queuename'

    # Spark
    SPARK_JAR_RESOURCE = 'tqs.spark.jar.resource'
    SPARK_JAR_CLASS = 'tqs.spark.jar.class'
    SPARK_JAR_CLASS_ARGS = 'tqs.spark.jar.class.args'
    SPARK_JAR_DEPEND_JARS = 'las.spark.jar.depend.jars'
    SPARK_JAR_DEPEND_FILES = 'las.spark.jar.depend.files'
    SPARK_JAR_DEPEND_PYFILES = 'las.spark.jar.depend.pyFiles'
    SPARK_JAR_DEPEND_ARCHIVES = 'las.spark.jar.depend.archives'

    # Flink
    FLINK_JAR_RESOURCE_SCHEMA = 'tqs.flink.jar.main.resource.schema'
    FLINK_JAR_RESOURCE_NAME = 'tqs.flink.jar.main.resource.name'
    FLINK_JAR_CLASS = 'tqs.flink.jar.main.class'
    FLINK_JAR_CLASS_ARGS = 'tqs.flink.jar.main.args.map'

    # RayJob
    RAY_RUNTIME_ENV_YAML_PATH = 'serverless.ray.runtime.env.json'
    RAY_HEAD_CPU = 'serverless.ray.head.cpu'
    RAY_HEAD_MEMORY = 'serverless.ray.head.memory'
    RAY_WORKER_CPU = 'serverless.ray.worker.cpu'
    RAY_WORKER_MEMORY = 'serverless.ray.worker.memory'
    RAY_WORKER_REPLICAS = 'serverless.ray.worker.replicas'
    RAY_ENTRYPOINT_CMD = 'serverless.ray.entrypoint.cmd'
    RAY_ENTRYPOINT_BUNDLE_PATH = 'serverless.ray.entrypoint.bundle.path'
    SERVERLESS_COMPUTE_GROUP_NAME = 'serverless.compute.group.name'
