import json
import time
from typing import Callable

from dpquerycore.api_service import ApiService
from dpquerycore.auth import Credentials, Identity
from dpquerycore.consts import Constants
from dpquerycore.enums import JobStatus, EngineType, TaskType, SQLType
from dpquerycore.exceptions import QuerySdkError
from dpquerycore.result import Result
from dpquerycore.utils import preset_interval_growth_func


class Job(object):
    """
    Job instance.
    """

    def __init__(self, job_info: dict):
        self._client = None
        self._api_service = None
        self._credentials = None
        self._identity = None
        self._job_info = job_info
        self.__update_props()

    def with_service(self, api_service: ApiService, credentials: Credentials, identity: Identity = None):
        self._api_service = api_service
        self._credentials = credentials
        self._identity = identity
        return self

    def with_client(self, client: 'BaseQueryClient'):
        self._client = client
        return self

    @property
    def id(self) -> str:
        return self._id

    @property
    def name(self) -> str:
        return self._name

    @property
    def queue_name(self) -> str:
        return self._queue_name

    @property
    def submitter(self) -> str:
        return self._submitter

    @property
    def origin(self) -> str:
        return self._origin

    @property
    def conf(self) -> dict:
        return self._conf

    @property
    def query(self) -> str:
        return self._query

    @property
    def status(self) -> JobStatus:
        return self._status

    @property
    def task_type(self) -> TaskType:
        return TaskType.from_engine(self.get_engine())

    @property
    def start_time(self):
        return self._start_time

    @property
    def end_time(self):
        return self._end_time

    def get_tracking_url(self) -> str:
        """
        Gets the engine tracking UI url for the job
        :return: tracking url
        """
        return self._api_service.get_tracking_url(self.id)(self._credentials, self._identity)

    def get_error(self) -> str:
        """
        Gets the error info for job.
        :return: error info message
        :raise: Quer
        """
        return self._api_service.get_error_info(self.id)(self._credentials, self._identity)

    def get_result(self) -> Result:
        """Gets the query result for job.

        Returns:

        """
        """
        Gets the query result for job.
        :return:
        """
        return self._client.get_result(self)

    def get_result_url(self) -> str:
        """

        Returns:

        """
        return self._api_service.get_result_url(self.id)(self._credentials, self._identity)

    def get_engine(self) -> EngineType:
        return EngineType.from_str(self._engine)

    def get_sql_type(self) -> SQLType:
        assert self.task_type == TaskType.SQL, 'Only sql tasks are supported'
        return SQLType.from_str(self._sql_type)

    def refresh(self):
        refreshed_inst = self._client.get_job(self.id)
        self.__refresh(refreshed_inst)
        return self

    def cancel(self) -> bool:
        return self._client.cancel_job(self)

    def is_success(self) -> bool:
        return JobStatus.is_success(self.status)

    def is_failed(self) -> bool:
        return JobStatus.is_failed(self.status)

    def is_finished(self) -> bool:
        return JobStatus.is_finished(self.status)

    def wait_for_finished(self,
            timeout: float = Constants.DEFAULT_SYNC_WAIT_TIMEOUT,
            interval_func: Callable[[float], float] = lambda elapsed: preset_interval_growth_func(elapsed)):
        self.wait_for(self.is_finished, timeout, interval_func)

    def wait_for(self,
            when_to_exit: Callable[[], bool],
            timeout: float = Constants.DEFAULT_SYNC_WAIT_TIMEOUT,
            interval_func: Callable[[float], float] = lambda elapsed: preset_interval_growth_func(elapsed)):
        self.refresh()
        self.__check_failed()
        _loop_start = time.time()
        _tombstone = _loop_start + timeout
        while not when_to_exit():
            try:
                _cur = time.time()
                if _cur > _tombstone:
                    raise TimeoutError("task execution timeout")
                _interval = interval_func(_cur - _loop_start)
                time.sleep(_interval)
            except TimeoutError as te:
                raise QuerySdkError('JobError', "Job execution wait timed out") from te
            self.refresh()
            self.__check_failed()

    def __update_props(self):
        self.__check_resp()
        self._id = str(self.__get_or_default('Id'))
        self._name = self.__get_or_default('Name')
        self._queue_name = self.__get_or_default('QueueName')
        self._submitter = self.__get_or_default('Submitter')
        self._origin = self.__get_or_default('Origin')
        self._conf = json.loads(self.__get_or_default('Conf', '{}'))
        self._query = self.__get_or_default('Json', '')
        self._status = JobStatus.from_str(self.__get_or_default('Status', ''))
        self._start_time = self.__get_or_default('StartTime', None)
        self._end_time = self.__get_or_default('FinishTime', None)
        self._engine = self.__get_or_default('EngineType', None)
        self._progress = json.loads(self.__get_or_default('Progress', '{}'))
        self._sql_type = self.__get_or_default('SqlType', SQLType.UNKNOWN)
        self._tracking_url_enabled = self.__get_or_default('TrackingUrlEnabled', False)
        self._submit_log_enabled = self.__get_or_default('SubmitLogEnabled', False)
        self._driver_log_enabled = self.__get_or_default('DriverLogEnabled', False)

    def __refresh(self, job: 'Job'):
        self._job_info = job._job_info
        self.__update_props()

    def __check_failed(self):
        if self.is_finished() and not self.is_success():
            raise QuerySdkError('JobError',
                'The job[%s] is failed or cancelled. See more details by checking submission log and driver log '
                'using client.get_submission_log() & client.get_driver_log()' % self.id)

    def __get_or_default(self, prop: str, default=None):
        return getattr(self._job_info, prop) if hasattr(self._job_info, prop) else default

    def __check_resp(self):
        _required_fields = ['Id', 'SubmitLogEnabled', 'Submitter',
            'TrackingUrlEnabled', 'Origin', 'QueueName', 'StartTime',
            'SubmitterType', 'Progress', 'EngineType', 'Conf',
            'DriverLogEnabled', 'Json', 'Status', "SqlType"
        ]
        for f in _required_fields:
            if not hasattr(self._job_info, f):
                raise QuerySdkError('UnexpectedError',
                    'Got unexpected api resp, please retry or contact us. missing_field = %s' % f
                )
