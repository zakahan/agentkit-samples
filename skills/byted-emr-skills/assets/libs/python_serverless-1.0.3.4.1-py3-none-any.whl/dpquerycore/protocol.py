from typing import TypeVar, Optional, List

from pydantic import BaseModel

T = TypeVar('T')


class Error(BaseModel):
    Code: Optional[str] = None
    CodeN: Optional[int] = None
    Message: Optional[str] = None


class ResponseMetadata(BaseModel):
    RequestId: Optional[str] = None
    Action: Optional[str] = None
    Version: Optional[str] = None
    Service: Optional[str] = None
    Region: Optional[str] = None
    Error: Optional['Error'] = None


class BaseProtocol(BaseModel):
    ResponseMetadata: 'ResponseMetadata'


class OperationResult(BaseModel):
    Success: bool


class QueryGetJobV2Result(BaseModel):
    SqlType: Optional[str] = None
    Id: Optional[str] = None
    Name: Optional[str] = None
    DataleapTaskId: Optional[str] = None
    DurationStage: Optional[int] = None
    Duration: Optional[str] = None
    SubmitLogEnabled: Optional[bool] = None
    QueueRole: Optional[str] = None
    Submitter: Optional[str] = None
    TrackingUrlEnabled: Optional[bool] = None
    Origin: Optional[str] = None
    QueueName: Optional[str] = None
    StartTime: Optional[str] = None
    SubmitterType: Optional[str] = None
    JobType: Optional[str] = None
    Progress: Optional[str] = None
    EngineType: Optional[str] = None
    Conf: Optional[str] = None
    DriverLogEnabled: Optional[bool] = None
    FinishTime: Optional[str] = None
    Json: Optional[str] = None
    Status: Optional[str] = None


class QueryGetJobV2Response(BaseProtocol):
    Result: Optional['QueryGetJobV2Result'] = None


class QueryExplainQueryResult(BaseModel):
    AnalyzeTaskId: str


class QueryExplainQueryResponse(BaseProtocol):
    Result: Optional['QueryExplainQueryResult'] = None


class DescribeExplainQueryResultData(BaseModel):
    Code: Optional[int] = None
    ErrorMsg: Optional[str] = None
    Success: Optional[bool] = None
    UserName: Optional[str] = None
    Status: Optional[str] = None
    Cost: Optional[str] = None
    Error: Optional[str] = None
    ErrorShort: Optional[str] = None
    ErrorTrace: Optional[str] = None
    ServerAddress: Optional[str] = None
    AnalysisTime: Optional[str] = None


class DescribeExplainQueryResult(BaseModel):
    Status: str
    Data: DescribeExplainQueryResultData


class DescribeExplainQueryResponse(BaseProtocol):
    Result: Optional['DescribeExplainQueryResult'] = None


class CreateQueryResponse(BaseModel):
    jobId: int


class CancelQueryResponse(BaseProtocol):
    Result: Optional['OperationResult'] = None


class FetchResultsByBatchResponse(BaseModel):
    rows: List[List[str]] = []
    position: int
    isFinished: bool


class GetResultSchemaResponse(BaseProtocol):
    Result: Optional[List[List[str]]] = None


class GetTrackingURLResponse(BaseProtocol):
    Result: Optional[str] = None


class GetResultUrlResponse(BaseProtocol):
    Result: Optional[str] = None


class CheckJobStatusResult(BaseModel):
    Status: Optional[int] = None
    UpdatedTime: Optional[str] = None
    Error: Optional[str] = None


class CheckJobStatusResponse(BaseProtocol):
    Result: Optional['CheckJobStatusResult'] = None


class LogResult(BaseModel):
    Rows: List[str] = []
    Position: str
    IsFinished: bool


class LogResponse(BaseProtocol):
    Result: Optional['LogResult'] = None


class Job(BaseModel):
    Id: Optional[str] = None
    Name: Optional[str] = None
    Origin: Optional[str] = None
    Status: int = 0
    Submitter: Optional[str] = None
    SqlType: Optional[str] = None
    StartTime: Optional[str] = None
    JobType: Optional[str] = None
    Json: Optional[str] = None
    EngineType: Optional[str] = None
    TrackingUrlEnabled: bool = False
    SubmitLogEnabled: bool = False
    DriverLogEnabled: bool = False
    Duration: Optional[str] = None
    FinishTime: Optional[str] = None
    QueueRole: Optional[str] = None
    DurationStage: Optional[int] = None
    DataleapTaskId: Optional[str] = None
    QueueName: Optional[str] = None
    SubmitterType: Optional[str] = None


class ListJob(BaseModel):
    JobList: List['Job'] = []
    Limit: int
    Offset: int
    Total: int


class ListJobResponse(BaseProtocol):
    Result: Optional['ListJob'] = None


class IAMCredentials(BaseModel):
    ExpiredTime: Optional[str] = None
    CurrentTime: Optional[str] = None
    AccessKeyId: Optional[str] = None
    SecretAccessKey: Optional[str] = None
    SessionToken: Optional[str] = None


class IAMAssumedRoleUser(BaseModel):
    Trn: Optional[str] = None
    AssumedRoleId: Optional[str] = None


class AssumeRoleResult(BaseModel):
    Credentials: Optional[IAMCredentials] = None
    AssumedRoleUser: Optional[IAMAssumedRoleUser] = None


class AssumeRoleResponse(BaseProtocol):
    Result: Optional[AssumeRoleResult] = None


class QueueComponent(BaseModel):
    Id: Optional[str] = None
    Name: Optional[str] = None
    QueueId: Optional[str] = None
    QueueName: Optional[str] = None
    Status: Optional[str] = None
    EngineType: Optional[str] = None
    ApplyStrategy: Optional[str] = None
    WaitTimeoutMin: Optional[int] = None
    Description: Optional[str] = None
    CreateTime: Optional[str] = None
    StartTime: Optional[str] = None
    CreateBy: Optional[str] = None
    MinCu: Optional[int] = None
    MaxCu: Optional[int] = None
    Gpu: Optional[int] = None
    AssignedCu: Optional[int] = None
    AssignedGpu: Optional[int] = None
    Settings: Optional[str] = None
    ErrorMsg: Optional[str] = None


class ListQueueComponentResponse(BaseProtocol):
    Result: List['QueueComponent'] = []


class GetQueueComponentResponse(BaseProtocol):
    Result: Optional['QueueComponent'] = None


# TODO: stop/start/delete/modify 服务端返回 true/false
class StopQueueComponentResponse(BaseProtocol):
    Result: Optional[dict] = None


class StartQueueComponentResponse(BaseProtocol):
    Result: Optional[dict] = None


class DeleteQueueComponentResponse(BaseProtocol):
    Result: Optional[dict] = None


class ModifyQueueComponentResponse(BaseProtocol):
    Result: Optional[dict] = None


class GetQueueComponentSettingsResponse(BaseProtocol):
    Result: Optional[dict] = None


class SaveQueueComponentSettingsResponse(BaseProtocol):
    Result: Optional[dict] = None


class CreateQueueComponentResponse(BaseProtocol):
    # TODO: 服务端返回计算组id
    Result: Optional[dict] = None

