import os
import tempfile
import time
import zipfile

from tos import TosClientV2


def _get_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise ValueError('Missing environment variable %s' % name)
    return value


def _get_bucket(bucket: str = None) -> str:
    if bucket:
        return bucket
    env_bucket = os.getenv('TOS_BUCKET') or os.getenv('TOS_BUCKET_NAME')
    if env_bucket:
        return env_bucket
    raise ValueError('TOS_BUCKET_NAME 未填写，请通过 client 传入 tos_bucket 或设置 TOS_BUCKET/TOS_BUCKET_NAME')


def _build_object_key(file_name: str) -> str:
    date = time.strftime('%Y%m%d')
    timestamp = str(int(time.time() * 1000))
    return 'emr-serverless-%s/%s/%s' % (date, timestamp, file_name)


def _expand_path(path: str) -> str:
    return os.path.abspath(os.path.expanduser(path))


def _create_client(access_key: str = None, secret_key: str = None, endpoint: str = None, region: str = None) -> TosClientV2:
    ak = access_key or _get_env('TOS_ACCESS_KEY')
    sk = secret_key or _get_env('TOS_SECRET_KEY')
    region = region or os.getenv('TOS_REGION') or os.getenv('VOLCENGINE_REGION')
    if not region:
        raise ValueError('TOS_REGION 未填写，请通过 client 传入 tos_region 或设置 TOS_REGION/VOLCENGINE_REGION')
    endpoint = endpoint or os.getenv('TOS_ENDPOINT', f'https://tos-{region}.volces.com')
    return TosClientV2(ak, sk, endpoint, region)


def _is_tos_path(path: str) -> bool:
    return path.startswith('tos://')


def _is_probably_local(path: str) -> bool:
    if path.startswith(('/', './', '../', '~')):
        return True
    return os.path.exists(_expand_path(path))


def _upload_file(file_path: str, access_key: str = None, secret_key: str = None, bucket: str = None,
                 endpoint: str = None, region: str = None) -> str:
    if not os.path.exists(file_path) or not os.path.isfile(file_path):
        raise ValueError('File not found: %s' % file_path)
    bucket = _get_bucket(bucket)
    resolved_region = region or os.getenv('TOS_REGION') or os.getenv('VOLCENGINE_REGION')
    resolved_endpoint = endpoint or os.getenv('TOS_ENDPOINT', f'https://tos-{resolved_region}.volces.com')
    object_key = _build_object_key(os.path.basename(file_path))
    client = _create_client(access_key=access_key, secret_key=secret_key, endpoint=resolved_endpoint, region=resolved_region)
    try:
        client.put_object_from_file(bucket, object_key, file_path)
    except Exception as e:
        raise ValueError('TOS 上传失败，请检查 TOS_BUCKET_NAME 是否填写，确认 TOS_ENDPOINT 是否可访问。'
                         '当前使用的 TOS_ENDPOINT: %s' % resolved_endpoint) from e
    finally:
        client.close()
    return 'tos://%s/%s' % (bucket, object_key)


def ensure_tos_path(path: str, credentials=None, bucket: str = None, endpoint: str = None, region: str = None) -> str:
    if not path:
        return path
    if _is_tos_path(path):
        return path
    if not _is_probably_local(path):
        return path
    access_key = credentials.ak if credentials else None
    secret_key = credentials.sk if credentials else None
    return _upload_file(_expand_path(path), access_key=access_key, secret_key=secret_key, bucket=bucket,
                        endpoint=endpoint, region=region)


def ensure_tos_paths(paths: list, credentials=None, bucket: str = None, endpoint: str = None, region: str = None) -> list:
    if not paths:
        return paths
    return [ensure_tos_path(p, credentials, bucket=bucket, endpoint=endpoint, region=region) for p in paths]


def ensure_tos_bundle_path(path: str, credentials=None, bucket: str = None, endpoint: str = None, region: str = None) -> str:
    if not path:
        return path
    if _is_tos_path(path):
        return path
    if not _is_probably_local(path):
        return path
    local_path = _expand_path(path)
    if not os.path.exists(local_path):
        raise ValueError('File or directory not found: %s' % path)
    if os.path.isfile(local_path) and local_path.endswith('.zip'):
        access_key = credentials.ak if credentials else None
        secret_key = credentials.sk if credentials else None
        return _upload_file(local_path, access_key=access_key, secret_key=secret_key, bucket=bucket,
                            endpoint=endpoint, region=region)
    with tempfile.TemporaryDirectory() as temp_dir:
        base_name = os.path.basename(local_path.rstrip(os.path.sep))
        zip_path = os.path.join(temp_dir, '%s.zip' % base_name)
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            if os.path.isdir(local_path):
                for root, _, files in os.walk(local_path):
                    for file_name in files:
                        full_path = os.path.join(root, file_name)
                        rel_path = os.path.relpath(full_path, os.path.dirname(local_path))
                        zipf.write(full_path, rel_path)
            else:
                zipf.write(local_path, base_name)
        access_key = credentials.ak if credentials else None
        secret_key = credentials.sk if credentials else None
        return _upload_file(zip_path, access_key=access_key, secret_key=secret_key, bucket=bucket,
                            endpoint=endpoint, region=region)
