import logging
import os
import re
import time
from typing import TypeVar, Callable, Type

from pydantic import ValidationError

from dpquerycore.consts import Constants
from dpquerycore.exceptions import QuerySdkError
from dpquerycore.protocol import T, BaseProtocol


def strip_prefix(text, prefix):
    if text.startswith(prefix):
        return text[len(prefix):]
    return text


def strip_suffix(text, suffix):
    if suffix and text.endswith(suffix):
        return text[:-len(suffix)]
    return text


def validate_and_parse_response(resp: str, cls: Type[T]) -> T:
    try:
        _res_obj = cls.parse_raw(resp)
        if isinstance(_res_obj, BaseProtocol) and _res_obj.ResponseMetadata and _res_obj.ResponseMetadata.Error:
            raise QuerySdkError(getattr(_res_obj.ResponseMetadata.Error, 'Code', None),
                getattr(_res_obj.ResponseMetadata.Error, 'Message', None),
                getattr(_res_obj.ResponseMetadata, 'RequestId', None))
        return _res_obj
    except QuerySdkError as le:
        raise le
    except ValidationError as ve:
        raise QuerySdkError('ServerInternalError', 'Invalid server response: ' + str(ve)) from ve
    except Exception as e:
        raise QuerySdkError('UnknownError', 'Got unexpected error: ' + str(e)) from e


def get_sys_env(variable_name, default=None):
    """Retrieve the value of a system environment variable.

        Args:
            variable_name (str): Name of the environment variable.
            default: Default value to return if the variable is not found (default=None).

        Returns:
            The value of the environment variable, or the default value if not found.
        """
    return os.environ.get(variable_name, default)


def preset_interval_growth_func(elapsed: float) -> float:
    if elapsed <= 10:
        return 0.3
    elif elapsed < Constants.MINUTE:
        return 1.0
    else:
        return 3.0


T = TypeVar('T')
R = TypeVar('R')


def sync_execute(submit: Callable[[T], str],
                 params: T,
                 fetch_result: Callable[[str], R],
                 check_complete: Callable[[R], bool]) -> R:
    _job_id = submit(params)
    _job_complete = False
    _start = time.time()

    _result = None
    while not _job_complete:
        _elapsed = time.time() - _start
        _sleep_interval = preset_interval_growth_func(_elapsed)
        time.sleep(_sleep_interval)
        _result = fetch_result(_job_id)
        _job_complete = check_complete(_result)

    return _result


def retry_with_delay(func, retry_times: int = 3, delay_interval: int = 3, *args, **kwargs):
    attempts = 0
    while attempts < retry_times:
        try:
            return func(*args, **kwargs)
        except Exception as e:
            attempts += 1
            if attempts < retry_times:
                time.sleep(delay_interval)
            else:
                raise e

    return None


def retry_top_api(func: Callable[[], str], retry_times: int = 10, delay_interval: int = 5):
    retry_errors = {"InternalServiceError", "InternalServiceTimeout"}
    attempts = 0
    while attempts < retry_times:
        try:
            resp = func()
            if '"Error"' in resp:
                validate_and_parse_response(resp, BaseProtocol)
            return resp
        except QuerySdkError as e:
            logging.error(e)
            attempts += 1
            should_raise = True
            if e.error_code == 'UnknownError' or e.error_code in retry_errors:
                logging.warning(f"retry top api cause by {e.error_code}")
                if attempts < retry_times:
                    time.sleep(delay_interval)
                    should_raise = False
            if should_raise:
                raise e

        except Exception as e:
            attempts += 1
            if attempts < retry_times:
                time.sleep(delay_interval)
            else:
                raise e
    return None


def is_matched_regex(pattern, string):
    if re.search(pattern, string):
        return True
    else:
        return False


def require(condition, error_message):
    if not condition:
        raise ValueError(error_message)
