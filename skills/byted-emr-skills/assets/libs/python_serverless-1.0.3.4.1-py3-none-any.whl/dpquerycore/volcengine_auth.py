# -*- coding: utf-8 -*-
import json
from urllib.parse import urlencode

from volcengine.auth.MetaData import MetaData
from volcengine.auth.SignResult import SignResult
from volcengine.auth.SignerV4 import SignerV4
from volcengine.base.Request import Request
from volcengine.sts.StsService import StsService
from volcengine.util.Util import Util

from dpquerycore.auth import Credentials
from dpquerycore.consts import Constants
from dpquerycore.protocol import AssumeRoleResponse
from dpquerycore.utils import validate_and_parse_response


class CustomSignerV4(object):
    @staticmethod
    def sign(request, credentials: Credentials, service: str, region: str):
        if request.path == '':
            request.path = '/'
        if request.method != 'GET' and not ('Content-Type' in request.headers):
            request.headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=utf-8'

        format_date = SignerV4.get_current_format_date()
        request.headers['X-Date'] = format_date

        md = MetaData()
        md.set_algorithm('HMAC-SHA256')
        md.set_service(service)
        md.set_region(region)
        md.set_date(format_date[:8])

        hashed_canon_req = SignerV4.hashed_canonical_request_v4(request, md)
        md.set_credential_scope(
            '/'.join([md.date, md.region, md.service, 'request']))

        signing_str = '\n'.join(
            [md.algorithm, format_date, md.credential_scope, hashed_canon_req])
        signing_key = SignerV4.get_signing_secret_key_v4(
            credentials.sk, md.date, md.region, md.service)
        sign = Util.to_hex(Util.hmac_sha256(signing_key, signing_str))
        request.headers['Authorization'] = SignerV4.build_auth_header_v4(
            sign, md, credentials)
        return

    @staticmethod
    def sign_url(request, credentials: Credentials, service: str, region: str):
        format_date = SignerV4.get_current_format_date()
        date = format_date[:8]

        md = MetaData()
        md.set_date(date)
        md.set_service(service)
        md.set_region(region)
        md.set_signed_headers('')
        md.set_algorithm('HMAC-SHA256')
        md.set_credential_scope(
            '/'.join([md.date, md.region, md.service, 'request']))

        query = request.query
        query['X-Date'] = format_date
        query['X-NotSignBody'] = ''
        query['X-Credential'] = credentials.ak + '/' + md.credential_scope
        query['X-Algorithm'] = md.algorithm
        query['X-SignedHeaders'] = md.signed_headers
        query['X-SignedQueries'] = ''
        query['X-SignedQueries'] = ';'.join(sorted(query.keys()))

        hashed_canon_req = SignerV4.hashed_simple_canonical_request_v4(
            request, md)
        signing_str = '\n'.join(
            [md.algorithm, format_date, md.credential_scope, hashed_canon_req])
        signing_key = SignerV4.get_signing_secret_key_v4(
            credentials.sk, md.date, md.region, md.service)
        sign = SignerV4.signature_v4(signing_key, signing_str)

        query['X-Signature'] = sign
        return urlencode(query)

    @staticmethod
    def sign_only(param, credentials: Credentials, service: str, region: str):
        request = Request()
        request.host = param.host
        request.method = param.method
        request.path = param.path
        request.body = param.body
        request.query = param.query
        request.headers = param.header_list

        format_date = param.date.strftime("%Y%m%dT%H%M%SZ")
        date = format_date[:8]
        request.headers['X-Date'] = format_date
        md = MetaData()
        md.set_algorithm('HMAC-SHA256')
        md.set_service(service)
        md.set_region(region)
        md.set_date(date)
        md.set_credential_scope(
            '/'.join([md.date, md.region, md.service, 'request']))

        if param.is_sign_url:
            md.set_signed_headers('')
            md.set_credential_scope(
                '/'.join([md.date, md.region, md.service, 'request']))
            query = request.query
            query['X-Date'] = format_date
            query['X-NotSignBody'] = ''
            query['X-Credential'] = credentials.ak + '/' + md.credential_scope
            query['X-Algorithm'] = md.algorithm
            query['X-SignedHeaders'] = md.signed_headers
            query['X-SignedQueries'] = ''
            query['X-SignedQueries'] = ';'.join(sorted(query.keys()))
            hashed_canon_req = SignerV4.hashed_simple_canonical_request_v4(
                request, md)
        else:
            hashed_canon_req = SignerV4.hashed_canonical_request_v4(
                request, md)

        signing_str = '\n'.join(
            [md.algorithm, format_date, md.credential_scope, hashed_canon_req])
        signing_key = SignerV4.get_signing_secret_key_v4(
            credentials.sk, md.date, md.region, md.service)
        sign = SignerV4.signature_v4(signing_key, signing_str)

        result = SignResult()
        result.xdate = format_date
        result.xAlgorithm = md.algorithm
        if param.is_sign_url:
            result.xSignedQueries = request.query['X-SignedQueries']
        result.xSignedHeaders = md.signed_headers
        result.xCredential = credentials.ak + '/' + md.credential_scope
        result.xSignature = sign
        result.authorization = result.xAlgorithm + " Credential=" + result.xCredential + \
            ", SignedHeaders=" + md.signed_headers + ", Signature=" + result.xSignature

        return result


class STSUtils(object):
    @staticmethod
    def assume_role(ak: str, sk: str, role_session_name: str,
            role_trn: str, ttl: int = 5 * Constants.MINUTE):
        sts_service = StsService()
        sts_service.set_ak(ak)
        sts_service.set_sk(sk)

        params = {
            "DurationSeconds": str(ttl),
            "RoleSessionName": role_session_name,
            "RoleTrn": role_trn
        }

        return validate_and_parse_response(json.dumps(sts_service.assume_role(params)), AssumeRoleResponse)
