from serverless.auth import StaticCredentials
from serverless.client import ServerlessClient


ak = 'AKLTODI0NTU4Y2I4ZDc5NGEyZWEzNGMzMTVmNGFkNGI3Mzc' # ignore_security_alert
sk = 'TldSaFpXUXhOMlF5TldabE5HRmxPR0UzT1dObE5USTNNbVJtWlRVeFlUZw=='
region = 'cn-beijing'
endpoint = 'open.volcengineapi.com'
service = 'emr_serverless_baseline'
connection_timeout = 30
socket_timeout = 30

client = ServerlessClient(credentials=StaticCredentials(ak, sk), region=region, endpoint=endpoint, service=service,
                          connection_timeout=connection_timeout, socket_timeout=socket_timeout)


def test_create_queue_component():
    settings = {
        "image": "image-repo-cn-beijing.cr.volces.com/emr-serverless-ray/ray:2.39.0-py3.11-ubuntu20.04-374-3.13.0",
        "imageCustomized": False,
        "headCpu": 8,
        "headMem": "32Gi",
        "workerCpu": 8,
        "workerMem": "32Gi",
        "workerReplicas": 1,
        "autoScaling": False,
        "workerMaxReplicas": 1,
        "workerGpu": 1,
        "workerMgpuCore": 10,
        "workerMgpuMemory": "1024",
        "customConf": "serverless.tos.mount=[{\"tosPath\": \"tos://testray0811/\", \"mountPath\": \"/tmp/hhh\", \"readOnly\": true, \"ak\": \"xx\", \"sk\": \"xx==\", \"capacity\": \"100Gi\", \"name\": \"testname\"},{\"tosPath\": \"tos://testray0812/\", \"mountPath\": \"/tmp/ggg\", \"readOnly\": false, \"ak\": \"xx\", \"sk\": \"xx==\", \"capacity\": \"100Gi\"}]",
    }
    result = client.create_compute_group("1443991461338021888", "ziwen", "Ray", "wait", "2", settings, "from sdk")
    print(result)


def test_list_compute_group():
    res = client.list_compute_group(queue_id="1403768509200072704", engine_type=["Ray"], name= "wxx")
    print(res)


def test_get_compute_group():
    res = client.get_compute_group(queue_id="1450161398582607872", compute_group_id="1450507931719041024")
    print(res)


def test_stop_compute_group():
    res = client.stop_compute_group(compute_group_id="1444031659539169280")
    print(res)


def test_start_compute_group():
    res = client.start_compute_group(compute_group_id="1447901379044573184", apply_strategy="wait", wait_timeout_min=10)
    print(res)


def test_delete_compute_group():
    a = client.delete_compute_group(compute_group_id="1455609303019814912")
    print(a)


def test_modify_compute_group():
    settings = {
        "image": "image-repo-cn-beijing.cr.volces.com/emr-serverless-ray/ray:2.39.0-py3.11-ubuntu20.04-374-3.13.0",
        "imageCustomized": False,
        "headCpu": 8,
        "headMem": "24Gi",
        "workerCpu": 8,
        "workerMem": "16Gi",
        "workerReplicas": 1,
        "autoScaling": False,
        "workerMaxReplicas": 1,
        "workerMgpuCore": 0,
        "workerMgpuMemory": ""
    }
    result = client.modify_compute_group(
        queue_id="1443991461338021888",
        compute_group_id="1455609303019814912",
        name="ziwen",
        engine_type="Ray",
        apply_strategy="wait",
        wait_timeout_min=10,
        description="modified from sdk",
        settings=settings
    )
    print(result)


def test_get_compute_group_custom_conf():
    res = client.get_compute_group_custom_conf(
        queue_id="1403768509200072704",
        compute_group_id="1410209634051948544"
    )
    print(res)


def test_update_compute_group_custom_conf():
    custom_settings = {
        "c": "d"
    }
    res = client.update_compute_group_custom_conf(
        queue_id="1403768509200072704",
        compute_group_id="1410209634051948544",
        custom_settings=custom_settings
    )
    print(res)


if __name__ == '__main__':
    # test_create_queue_component()
    # test_list_compute_group()
    # test_get_compute_group()
    # test_stop_compute_group()
    test_start_compute_group()
    # test_delete_compute_group()
    # test_modify_compute_group()
    # test_get_compute_group_custom_conf()
    # test_update_compute_group_custom_conf()
