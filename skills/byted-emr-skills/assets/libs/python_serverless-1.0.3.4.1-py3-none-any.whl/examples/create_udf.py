def create_udf():
    from las.auth import StaticCredentials
    from las.client import LASClient
    from las.task import SQLTask
    from las.exceptions import LASError

    ak = '${ak}'
    sk = '${sk}'
    region = 'cn-beijing'
    endpoint = 'las.volcengineapi.com'

    client = LASClient(credentials=StaticCredentials(ak, sk), region=region,
                       endpoint=endpoint, service='las_sdk_test')

    try:
        create_udf_job = client.execute(task=SQLTask(name='create udf',
                                                     query="CREATE FUNCTION minreng_test_db_2.sortstring2 AS 'com.bytedance.hive.udf.dp.SortString' using jar 'testywudf.new'",
                                                     conf={}), is_sync=True)

        if create_udf_job.is_success():
            job = client.execute(task=SQLTask(name='apply udf',
                                        query="select minreng_test_db_2.sortstring2(name) from testywudf.test1 where date='20210928' limit 10",
                                        conf={}), is_sync=True)
            if job.is_success():
                result = job.get_result()
                for record in result:
                    print(', '.join([col for col in record]))

    except LASError as e:
        print(
            "Error in creating or apply udf. code = %s, error = %s" % (
                e.code, e.message))


if __name__ == "__main__":
    create_udf()
