def execute_flink_jar_task():
    from las.auth import StaticCredentials
    from las.client import LASClient
    from las.resource import JarResourceInfo
    from las.task import FlinkJarTask
    import time

    ak = '${ak}'
    sk = '${sk}'
    region = 'cn-beijing'
    endpoint = 'las.volcengineapi.com'

    client = LASClient(credentials=StaticCredentials(ak, sk), region=region,
                       endpoint=endpoint, service='las_sdk_test')

    schema = 'sunxh_test0107'
    resource_name = 'flinkjartest01'
    main_class = 'com.bytedance.FlinkTaskDriver'
    main_args = {}

    job = client.execute(task=FlinkJarTask(name='',
                                           jar=JarResourceInfo.of(
                                               schema=schema,
                                               name=resource_name),
                                           main_class=main_class,
                                           main_args=main_args,
                                           conf={
                                               'flink.hdfs.ipc.ping.interval': '10250'}),
                         is_sync=False)

    def when_to_exit() -> bool:
        return job.get_tracking_url() is not None

    job.wait_for(when_to_exit=when_to_exit, timeout=180)
    print('Tracking Url: %s' % job.get_tracking_url())

    time.sleep(60)
    job.cancel()
    print('The task has been cancelled after running for 1 minute.')


if __name__ == "__main__":
    execute_flink_jar_task()
