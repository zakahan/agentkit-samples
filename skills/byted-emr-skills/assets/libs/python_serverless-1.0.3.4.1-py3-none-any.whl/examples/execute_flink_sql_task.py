def execute_flink_sql_task():
    from las.auth import StaticCredentials
    from las.client import LASClient
    from las.task import FlinkSQLTask
    import time

    ak = '${ak}'
    sk = '${sk}'
    region = 'cn-beijing'
    endpoint = 'las.volcengineapi.com'

    client = LASClient(credentials=StaticCredentials(ak, sk), region=region,
                       endpoint=endpoint, service='las_sdk_test')

    sql = """
                CREATE TEMPORARY TABLE source
                (
                        f_sequence INT
                )
                WITH (
                        'connector' = 'datagen',
                        'rows-per-second' = '5',
                        'fields.f_sequence.kind' = 'sequence',
                        'fields.f_sequence.start' = '1',
                        'fields.f_sequence.end' = '1000000'
                );

                CREATE TEMPORARY TABLE sink
                (
                        f_sequence INT
                )
                WITH (
                        'connector' = 'print',
                        'print-sample-ratio' = '1'
                );

                INSERT INTO sink
                SELECT *
                FROM source;
            """

    job = client.execute(task=FlinkSQLTask(name='',
                                           sql=sql,
                                           conf={
                                               'flink.hdfs.ipc.ping.interval': '10250'}),
                         is_sync=False)

    def when_to_exit() -> bool:
        return job.get_tracking_url() is not None

    job.wait_for(when_to_exit=when_to_exit, timeout=300)
    print('Tracking Url: %s' % job.get_tracking_url())

    time.sleep(60)
    job.cancel()
    print('The task has been cancelled after running for 1 minute.')


if __name__ == "__main__":
    execute_flink_sql_task()
