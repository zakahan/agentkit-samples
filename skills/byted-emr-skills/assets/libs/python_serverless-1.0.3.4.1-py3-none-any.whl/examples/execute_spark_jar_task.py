def execute_spark_jar_task():
    from las.auth import StaticCredentials
    from las.client import LASClient
    from las.resource import JarResourceInfo
    from las.task import SparkJarTask

    ak = '${ak}'
    sk = '${sk}'
    region = 'cn-beijing'
    endpoint = 'las.volcengineapi.com'

    client = LASClient(credentials=StaticCredentials(ak, sk), region=region,
                       endpoint=endpoint, service='las_sdk_test')

    schema = 'sunxh_0107'
    resource_name = 'sparkjar'
    main_class = 'SparkJar'
    job = client.execute(task=SparkJarTask(name="spark task",
                                           jar=JarResourceInfo.of(
                                               schema, resource_name),
                                           main_class=main_class,
                                           main_args=['arg_xxx', 'arg_yyy']
                                           ),
                         is_sync=False)

    def when_to_exit() -> bool:
        return job.get_tracking_url() is not None

    job.wait_for(when_to_exit=when_to_exit, timeout=300)
    print('Tracking Url: %s' % job.get_tracking_url())

    job.wait_for_finished()
    print('The task executed successfully.')


if __name__ == "__main__":
    execute_spark_jar_task()
