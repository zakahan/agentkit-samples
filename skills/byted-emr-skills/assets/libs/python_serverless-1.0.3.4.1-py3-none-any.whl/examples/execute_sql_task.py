from las.exceptions import LASError


def execute_sql_task():
    from las.auth import StaticCredentials
    from las.client import LASClient
    from las.task import SQLTask

    ak = '${ak}'
    sk = '${sk}'
    region = 'cn-beijing'
    endpoint = 'las.volcengineapi.com'
    sql = 'SELECT * FROM `sunxh_test0107`.`test_sourceparttotal` LIMIT 10'

    client = LASClient(credentials=StaticCredentials(ak, sk), region=region,
                       endpoint=endpoint, service='las_sdk_test')

    try:
        job = client.execute(task=SQLTask(name='sql task', query=sql, conf={
            'tqs.query.engine.type': 'Presto'}), is_sync=True)
        if job.is_success():
            result = job.get_result()
            for record in result:
                print(', '.join([col for col in record]))

    except LASError as e:
        print(
            "Error in executing sql task synchronously. code = %s, error = %s" % (
            e.code, e.message))


if __name__ == "__main__":
    execute_sql_task()
