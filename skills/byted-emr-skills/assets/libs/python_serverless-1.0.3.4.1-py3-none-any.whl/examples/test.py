from las.client import LASClient
from las.auth import StaticCredentials
from las.task import SQLTask

ak = '${ak}'
sk = '${sk}'
region = "cn-beijing"
endpoint = "https://las.volcengineapi.com"
client = LASClient(credentials=StaticCredentials(ak, sk), region=region, endpoint=endpoint)

sql = """
    SELECT 1
"""
# 同步执行查询
job = client.execute(task=SQLTask(name="first query task",
                            query=sql,
                            conf={}),
                    is_sync=True)
# 获取查询结果
if job.is_success():
    result = job.get_result()
    for record in result:
        print(', '.join([col for col in record]))

