def upload_and_list_resource():
    from las.auth import StaticCredentials
    from las.client import LASClient
    from las.exceptions import LASError
    from las.resource import FileResourceInfo

    ak = '${ak}'
    sk = '${sk}'
    region = 'cn-beijing'
    endpoint = 'las.volcengineapi.com'

    client = LASClient(credentials=StaticCredentials(ak, sk), region=region,
                       endpoint=endpoint, service='las_sdk_test')

    file_path = '../data/test_upload.csv'
    schema = 'olap_las_test_minreng'
    resource_name = 'test_file_312'
    description = '测试csv'

    try:
        client.upload_resource(
            FileResourceInfo(schema, resource_name, description), file_path)
        client.list_resources(schema)

    except LASError as e:
        print(
            "Error in uploading or listing resource. code = %s, error = %s" % (
            e.code, e.message))


if __name__ == "__main__":
    upload_and_list_resource()
