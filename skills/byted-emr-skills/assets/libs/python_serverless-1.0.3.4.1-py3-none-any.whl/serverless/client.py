from dpquerycore.base_client import BaseQueryClient
from dpquerycore.consts import Constants
from dpquerycore.protocol import ListJob
from serverless.api_service import ServerlessService
from serverless.auth import Credentials as ServerlessCredentials, StaticCredentials, Identity
from serverless.job import Job
from serverless.log import LogCursor
from serverless.result import Result
from serverless.task import Task


class ServerlessClient(BaseQueryClient):
    _api_slots = 'execute', 'get_job', 'get_result', 'cancel_job', 'analyze', \
        'get_submission_log', 'get_driver_log', 'list_job', 'create_compute_group', 'list_compute_group', 'get_compute_group', \
        'stop_compute_group', 'start_compute_group', 'delete_compute_group', 'modify_compute_group', \
        'get_compute_group_custom_conf', 'update_compute_group_custom_conf'

    def __init__(self,
            credentials: ServerlessCredentials,
            endpoint: str,
            service: str,
            region: str,
            scheme: str = 'https',
            connection_timeout: int = Constants.CONNECTION_TIMEOUT,
            socket_timeout: int = Constants.SOCKET_TIMEOUT,
            identity: Identity = None,
            tos_bucket: str = None,
            tos_region: str = None,
            tos_endpoint: str = None,
            **kwargs):
        """Initialize a query client instance.

        Args:
            credentials (ServerlessCredentials): credentials
            endpoint (str): endpoint
            service (str): service name
            region (str): region
            scheme (str): scheme
            connection_timeout (int): connection timeout (in seconds)
            socket_timeout (int): socket timeout (in seconds)
        """

        _api_service = ServerlessService(endpoint=endpoint, service=service,
            region=region, scheme=scheme,
            connection_timeout=connection_timeout,
            socket_timeout=socket_timeout)
        self._credentials = credentials
        self._api_service = _api_service
        self._identity = identity
        self._tos_bucket = tos_bucket
        self._tos_region = tos_region
        self._tos_endpoint = tos_endpoint
        super().__init__(self._api_service)

    def __getattribute__(self, name):
        attr = object.__getattribute__(self, name)
        if hasattr(attr, '__call__'):
            def call_with_credentials_and_identity(*args, **kwargs):
                if name in self._api_slots:
                    result = attr(*args, **kwargs)(self._credentials, self._identity)
                else:
                    result = attr(*args, **kwargs)
                return result

            return call_with_credentials_and_identity
        else:
            return attr

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def execute(self, task: Task, is_sync: bool = True, polling_interval: float = None,
            timeout: float = Constants.DEFAULT_SYNC_WAIT_TIMEOUT) -> Job:
        """Executes a task.

        Args:
            task (Task): task definition
            is_sync (bool): whether to execute the task synchronously
            polling_interval (float): polling interval for synchronous execution, in seconds
            timeout (float): timeout for synchronous execution, in seconds

        Returns:
            job: submitted job instance
        """
        return super().execute(task, is_sync, polling_interval, timeout)

    def get_job(self, job_id: str) -> Job:
        """Gets job instance by id.

        Args:
            job_id (str): job id

        Returns:
            job (Job): job instance
        """
        return super().get_job(job_id)

    def get_result(self, job: Job) -> Result:
        """Gets the query result of job. Only supported for sql tasks.

        Args:
            job (Job): job instance

        Returns:
            result (Result): job result instance
        """
        return super().get_result(job)

    def cancel_job(self, job: Job):
        """Cancels a job.

        Args:
            job (Job): job instance
        """
        return super().cancel_job(job)

    def analyze(self, task: Task):
        """Analyzes task. Only supported for sql tasks.

        Args:
            task (Task): task definition instance

        Raises:
            QuerySdkError: If the task analysis result failed.
        """
        return super().analyze(task)

    def get_submission_log(self, job: Job, page_size: int = 100) -> LogCursor:
        """Gets submission log cursor for job.

        Args:
            job (Job): job instance
            page_size (int): number of rows for each page

        Returns:
            log_cursor (LogCursor): log cursor
        """
        return super().get_submission_log(job, page_size)

    def get_driver_log(self, job: Job, page_size: int = 100) -> LogCursor:
        """Gets driver log cursor for job.

        Args:
            job (Job): job instance
            page_size (int): number of rows for each page

        Returns:
            log_cursor (LogCursor): log cursor
        """
        return super().get_driver_log(job, page_size)

    def list_job(self, job_id: str = "", job_name: str = "", start_time: str = "", finish_time: str = "", queue: str = "", limit: int = 20, offset: int = 0) -> ListJob:
        return super().list_job(job_id, job_name, start_time, finish_time, queue, limit, offset)

    def list_queues(self):
        pass

    def create_compute_group(self, queue_id: str, name: str, engine_type: str, apply_strategy: str, wait_timeout_min: int = None,
                             settings: dict = None, description: str = None) -> str:
        """Creates a compute group.

        Args:
            queue_id (str): Queue ID
            name (str): Compute group name
            engine_type (str): Engine type
            apply_strategy (str): Apply strategy
            wait_timeout_min (int, optional): Timeout in minutes when strategy is 'wait'
            settings (dict, optional): Compute group settings
            description (str, optional): Compute group description

        Returns:
            compute_group_id (str)
        """
        return super().create_compute_group(queue_id, name, engine_type, apply_strategy, wait_timeout_min,
                                           settings, description)

    def list_compute_group(self, queue_id: str = None, queue_name: str = None, status: list = None, \
            engine_type: list = None, name: str = None) -> list:
        """List compute groups.

        Args:
            queue_id (str, optional): Queue ID
            queue_name (str, optional): Queue name
            status (list, optional): Status filter
            engine_type (list, optional): Engine type filter
            name (str, optional): Compute group name filter

        Returns:
            list: List of compute groups
        """
        return super().list_compute_group(queue_id, queue_name, status, engine_type, name)

    def get_compute_group(self, queue_id: str, compute_group_id: str):
        """Gets compute group details.

        Args:
            queue_id (str): Queue ID
            compute_group_id (str): Compute group ID

        Returns:
            QueueComponent: Compute group details
        """
        return super().get_compute_group(queue_id, compute_group_id)

    def stop_compute_group(self, compute_group_id: str):
        """
        Stop a compute group

        Args:
            compute_group_id (str): The ID of the compute group to stop

        Returns:
            StopQueueComponentResponse: The response of stopping the compute group
        """
        return super().stop_compute_group(
            compute_group_id=compute_group_id
        )

    def start_compute_group(self, compute_group_id: str, apply_strategy: str, wait_timeout_min: int = None):
        """
        Start a compute group

        Args:
            compute_group_id (str): The ID of the compute group to start
            apply_strategy (str): Deployment strategy, 'wait' or 'preempt'
            wait_timeout_min (int, optional): Timeout in minutes when strategy is 'wait'

        Returns:
            StartQueueComponentResponse: The response of starting the compute group
        """
        return super().start_compute_group(
            compute_group_id=compute_group_id,
            apply_strategy=apply_strategy,
            wait_timeout_min=wait_timeout_min
        )

    def delete_compute_group(self, compute_group_id: str):
        """
        Delete a compute group

        Args:
            compute_group_id (str): The ID of the compute group to delete

        Returns:
            DeleteQueueComponentResponse: The response of deleting the compute group
        """
        return super().delete_compute_group(
            compute_group_id=compute_group_id
        )

    def modify_compute_group(self, queue_id: str, compute_group_id: str, name: str = None, engine_type: str = None, apply_strategy: str = None, wait_timeout_min: int = None, description: str = None, settings: dict = None):
        """
        Modify a compute group

        Args:
            queue_id (str): The ID of the queue that the compute group belongs to
            compute_group_id (str): The ID of the compute group to modify
            name (str, optional): New compute group name
            engine_type (str, optional): New engine type
            apply_strategy (str, optional): New apply strategy
            wait_timeout_min (int, optional): New timeout in minutes when strategy is 'wait'
            description (str, optional): New description
            settings (dict, optional): New settings

        Returns:
            ModifyQueueComponentResponse: The response of modifying the compute group
        """
        return super().modify_compute_group(
            queue_id=queue_id,
            compute_group_id=compute_group_id,
            name=name,
            engine_type=engine_type,
            apply_strategy=apply_strategy,
            wait_timeout_min=wait_timeout_min,
            description=description,
            settings=settings
        )

    def get_compute_group_custom_conf(self, queue_id: str, compute_group_id: str):
        """
        Get compute group custom settings

        Args:
            queue_id (str): The ID of the queue that the compute group belongs to
            compute_group_id (str): The ID of the compute group

        Returns:
            GetQueueComponentSettingsResponse: The response of getting the compute group settings
        """
        return super().get_compute_group_custom_conf(
            queue_id=queue_id,
            compute_group_id=compute_group_id
        )

    def update_compute_group_custom_conf(self, queue_id: str, compute_group_id: str, custom_settings: dict):
        """
        Save compute group custom settings

        Args:
            queue_id (str): The ID of the queue that the compute group belongs to
            compute_group_id (str): The ID of the compute group
            custom_settings (dict): The custom settings to save

        Returns:
            SaveQueueComponentSettingsResponse: The response of saving the compute group settings
        """
        return super().update_compute_group_custom_conf(
            queue_id=queue_id,
            compute_group_id=compute_group_id,
            custom_settings=custom_settings
        )

    def close(self):
        super().close()
