from dpquerycore.consts import Constants

from dpquerycore.task import SQLTask, JarTask, PySparkTask, Task, time, TaskConf, json, EngineType, TaskType
from dpquerycore.tos_auto import ensure_tos_bundle_path
from dpquerycore.utils import require, is_matched_regex


class SparkSQLTask(SQLTask):
    """
    SparkSQL task definition class.
    """

    def __init__(self, name: str, query: str, conf: dict, skip_analysis: bool = False, queue: str = None,
                 compute_group: str = None):
        """Initializes a new instance of SparkSQL.

        Args:
            name (str): task name
            query (str): sql statement to be executed
            conf (dict): task configs, should be a plain k-v string dict
            skip_analysis (bool): whether to skip the sql analysis stage
            queue (str): queue name, specified which queue this task runs on
        """
        super().__init__(name, query, conf, skip_analysis, queue, compute_group)


class SparkJarTask(JarTask):
    """
    Spark Jar task definition class.
    """

    def __init__(self, name: str, jar: str, main_class: str, main_args: list, depend_jars: list = [],
            files: list = [], archives: list = [], conf: dict = {}, queue: str = None, compute_group: str = None):
        """Initializes a new instance of SparkJarTask.

        Args:
            name (str): task name
            jar (str): jar resource reference
            main_class (str): main class reference, e.g. com.volcengine.emr.DemoUdf
            main_args (list): main class arguments
            depend_jars (list): extra jar dependencies references
            files (list): extra file dependencies references
            archives (list): extra archive dependencies references
            conf (dict): task configs, should be a plain k-v string dict
            queue (str): queue name, specified which queue this task runs on
        """
        super().__init__(name, jar, main_class, main_args, depend_jars, files, archives, conf, queue, compute_group)


class PrestoSQLTask(Task):
    """
    PrestoSQL task definition class.
    """

    def __init__(self,
            name: str,
            sql: str,
            conf: dict = {},
            queue: str = None,
            compute_group: str = None):
        """Initializes a new instance of PrestoSQLTask.

        Args:
            name (str): task name
            sql (str): presto sql statement to be executed
            conf (dict): task configs, should be a plain k-v string dict
            queue (str): queue name, specified which queue this task runs on
        """
        if name is None:
            name = 'PrestoSQLTask_%s' % time.time()
        if conf is None:
            conf = {}
        if sql is None:
            raise ValueError(
                "Missing required parameters for `sql`")
        conf[TaskConf.ENGINE_TYPE] = EngineType.Presto.name
        super(PrestoSQLTask, self).__init__(name, sql, conf, queue, compute_group)

    @property
    def type(self) -> TaskType:
        return TaskType.SQL


class RayJobTask(Task):
    """
    RayJob task definition class.
    """
    def __init__(self,
            name: str,
            entrypoint_cmd: str,
            entrypoint_resource: str,
            head_cpu: str = '4',
            head_memory: str = '16Gi',
            worker_cpu: str = '4',
            worker_memory: str = '16Gi',
            worker_replicas: int = 1,
            runtime_env: dict = {},
            conf: dict = {},
            queue: str = None,
            compute_group: str = None):
        """Initializes a new task definition instance of RayJob.

        Args:
            name (str): task name
            entrypoint_cmd (str): the shell command to run for RayJob
            entrypoint_resource (str): path to the resource file required for RayJob
            head_cpu (str): the quantity of CPU cores to reserve for head node
            head_memory (str): the quantity of memory to reserve for head node, in the same format as
                         k8s memory strings (e.g. 512Mi, 2G)
            worker_cpu (str): the quantity of CPU cores to reserve for per worker node
            worker_memory (str): the quantity of memory to reserve for per worker node, in the same format as
                           k8s memory strings (e.g. 512Mi, 2G)
            worker_replicas (int): number of workers
            runtime_env (dict): the runtime env dict
                                    e.g.
                                        {
                                            "working_dir": "./",
                                            "pip": ["requests==2.26.0", "pendulum==2.1.2"],
                                            "env_vars": {
                                                "counter_name": "test_counter"
                                            }
                                        }
            conf (dict): task configs, should be a plain k-v string dict
            queue (str): queue name, specified which queue this task runs on
        """
        if name is None:
            name = 'RayJobTask_%s' % time.time()
        if conf is None:
            conf = {}
        if entrypoint_cmd is None:
            raise ValueError(
                "Missing required parameters for `entrypoint_cmd`")
        self._entrypoint_cmd = entrypoint_cmd
        self._entrypoint_resource = entrypoint_resource
        self._head_cpu = head_cpu
        self._head_memory = head_memory
        self._worker_cpu = worker_cpu
        self._worker_memory = worker_memory
        self._worker_replicas = worker_replicas
        self._runtime_env = runtime_env

        for ele in [('head_cpu', self._head_cpu), ('head_memory', self._head_memory),
            ('worker_cpu', self._worker_cpu), ('worker_memory', self._worker_memory)
        ]:
            k, v = ele
            require(is_matched_regex(Constants.REGEX_K8S_RESOURCE_DEF_STRING, v),
                '%s=\'%s\' is not a valid resource definition. It should match `%s`' %
                (k, v, Constants.REGEX_K8S_RESOURCE_DEF_STRING))

        conf[TaskConf.RAY_ENTRYPOINT_CMD] = self._entrypoint_cmd
        # 客户代码可能打在镜像里
        if self._entrypoint_resource:
            conf[TaskConf.RAY_ENTRYPOINT_BUNDLE_PATH] = self._entrypoint_resource
        conf[TaskConf.RAY_HEAD_CPU] = self._head_cpu
        conf[TaskConf.RAY_HEAD_MEMORY] = self._head_memory
        conf[TaskConf.RAY_WORKER_CPU] = self._worker_cpu
        conf[TaskConf.RAY_WORKER_MEMORY] = self._worker_memory
        conf[TaskConf.RAY_WORKER_REPLICAS] = self._worker_replicas
        conf[TaskConf.ENGINE_TYPE] = EngineType.RayJob.name

        if self._runtime_env:
            conf[TaskConf.RAY_RUNTIME_ENV_YAML_PATH] = json.dumps(self._runtime_env)

        super(RayJobTask, self).__init__(name, '', conf, queue, compute_group)

    @property
    def entrypoint_cmd(self):
        return self._entrypoint_cmd

    @property
    def entrypoint_resource(self):
        return self._entrypoint_resource

    @property
    def head_cpu(self):
        return self._head_cpu

    @property
    def head_memory(self):
        return self._head_memory

    @property
    def worker_cpu(self):
        return self._worker_cpu

    @property
    def worker_memory(self):
        return self._worker_memory

    @property
    def worker_replicas(self):
        return self._worker_replicas

    @property
    def runtime_env(self):
        return self._runtime_env

    @property
    def type(self) -> TaskType:
        return TaskType.RayJob

    def prepare_resources(self, credentials, tos_bucket: str = None, tos_region: str = None, tos_endpoint: str = None):
        self._entrypoint_resource = ensure_tos_bundle_path(self._entrypoint_resource, credentials,
                                                          bucket=tos_bucket, region=tos_region, endpoint=tos_endpoint)
        if self._entrypoint_resource:
            self._conf[TaskConf.RAY_ENTRYPOINT_BUNDLE_PATH] = str(self._entrypoint_resource)
