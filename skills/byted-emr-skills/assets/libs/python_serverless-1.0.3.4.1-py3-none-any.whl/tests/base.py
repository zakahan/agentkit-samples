import json
import os
import time
from abc import ABC
from types import SimpleNamespace

import pytest

from las.auth import StaticCredentials, UserIdentity
from las.client import LASClient
from dpquerycore.consts import Constants
from dpquerycore.enums import JobStatus
from las.inner_client import InnerLASClient
from las.resource import FileResourceInfo
from las.task import SQLTask
from dpquerycore.utils import get_sys_env


class TestBase(ABC):
    test_schema = 'python_sdk_test_scm_%s' % int(time.time())

    @pytest.fixture
    def data_file_folder(self, request):
        relative_path = '../data/'
        file_path = os.path.abspath(os.path.join(request.fspath.dirname, relative_path))
        return file_path

    @pytest.fixture(scope='session')
    def account_client(self, request) -> LASClient:
        _region = request.param
        _ak = get_sys_env('ACCOUNT_ACCESS_KEY')
        _sk = get_sys_env('ACCOUNT_SECRET_KEY')
        assert _ak is not None and _sk is not None, \
            'Missing sys environment variable `ACCOUNT_ACCESS_KEY` or `ACCOUNT_SECRET_KEY`'
        _las = LASClient(
            StaticCredentials(_ak, _sk),
            endpoint=Constants.TOP_ENDPOINT,
            region=_region, scheme='https')
        self.create_test_scm(_las)
        self.upload_test_resources(_las)
        yield _las
        self.drop_test_scm(_las)
        _las.close()

    @pytest.fixture
    def sub_account_client(request):
        _region = request.param
        _ak = get_sys_env('SUB_ACCOUNT_ACCESS_KEY')
        _sk = get_sys_env('SUB_ACCOUNT_SECRET_KEY')
        _las = LASClient(
            StaticCredentials(_ak, _sk),
            endpoint=Constants.TOP_ENDPOINT,
            region=_region, scheme='https')
        yield _las
        _las.close()

    @pytest.fixture
    def assume_role_client(request):
        _region, _role_name, _target_account_id, _target_identity_id = request.param
        _ak = get_sys_env('ASSUME_ROLE_ACCESS_KEY')
        _sk = get_sys_env('ASSUME_ROLE_SECRET_KEY')
        _las = InnerLASClient(
            credentials=StaticCredentials(_ak, _sk),
            endpoint=Constants.TOP_ENDPOINT,
            region=Constants.REGION_CN_BEIJING
        ).of_assume_role(_role_name, UserIdentity(_target_account_id, _target_identity_id))
        yield _las
        _las.close()

    def drop_test_scm(self, _las):
        print("Teardown: drop the test schema `%s`")
        job = _las.execute(task=SQLTask(
            name="python_sdk_tear_down",
            query='DROP SCHEMA IF EXISTS %s CASCADE' % self.test_schema,
            conf={}), is_sync=True)
        assert job.status == JobStatus.COMPLETED

    def create_test_scm(self, _las):
        print("Setup for test schema `%s`" % self.test_schema)
        job = _las.execute(task=SQLTask(
            name="python_sdk_setup",
            query='create schema if not exists %s' % self.test_schema,
            conf={}), is_sync=True)
        assert job.status == JobStatus.COMPLETED

    @staticmethod
    def upload_resource(_las, schema, name, path, description):
        _las.upload_resource(
            FileResourceInfo(schema, name, description),
            path
        )

        return schema, name

    def upload_test_resources(self, _las):
        # success spark jar resource
        self.upload_resource(_las, self.test_schema, 'test_spark_jar',
            '../data/it_execute_spark_jar_success.jar', 'spark jar 测试')

        # success flink jar resource
        self.upload_resource(_las, self.test_schema, 'test_flink_jar',
            '../data/it_execute_flink_jar_success.jar', 'flink jar 测试')


def _mock_create_query_success():
    return json.loads(r"""
        {"jobId": "123456"}
    """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_analyze_sql_get_task_id():
    return json.loads(r"""
        {"AnalyzeTaskId": "123"}
    """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_analyze_sql_success():
    return json.loads(r"""
        {
            "Status":"AnalysisCompleted",
            "Data":{
                "Code":0,
                "ErrorMsg":"",
                "Success":true,
                "UserName":"las_sdk_user",
                "Status":"AnalysisCompleted",
                "Cost":"{\"stages\":1,\"row\":0.0,\"cpu\":0.0,\"io\":0.0,\"partitions\":0.0,\"limit\":0,\"tables\":0.0,\"isQuery\":false,\"memory\":0.0}",
                "Error":null,
                "ErrorShort":null,
                "ErrorTrace":null,
                "ServerAddress":"10.250.50.202:9438",
                "AnalysisTime":"4"
            }
        }
    """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_analyze_sql_failed():
    return json.loads(r"""
        {
            "Status":"AnalysisFailed",
            "Data":{
                "Code":0,
                "ErrorMsg":"",
                "Success":true,
                "UserName":"las_sdk_user",
                "Status":"AnalysisFailed",
                "Cost":null,
                "Error":"com.bytedance.las.AnalysisException: Sql 1 From line 1, column 8 to line 1, column 13: Table 'asdasd' not found",
                "ErrorShort":"Sql 1 From line 1, column 8 to line 1, column 13: Table 'asdasd' not found",
                "ErrorTrace":"com.bytedance.las.AnalysisException: Sql 1 From line 1, column 8 to line 1, column 13: Table 'asdasd' not found\n\tat com.bytedance.las.bytequery.parse.QueryAnalyzer.liftedTree3$1(QueryAnalyzer.scala:509)",
                "ServerAddress":"10.250.49.141:9295",
                "AnalysisTime":null
            }
        }
    """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_analyze_sql_processing():
    return json.loads(r"""
        {
            "Status":"Analyzing",
            "Data":null
        }
    """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_completed_sql_job():
    return json.loads(r"""
            {
                "SqlType":"DQL",
                "Id":"123456",
                "Name":"查询 01-17 10:29",
                "DataleapTaskId":"",
                "DurationStage":3,
                "Duration":"1827:29:08",
                "SubmitLogEnabled":true,
                "QueueRole":"none",
                "Submitter":"LasQATeam",
                "TrackingUrlEnabled":true,
                "Origin":"LAS Web UI",
                "QueueName":"benchmark",
                "StartTime":"2023-06-07 14:03:11",
                "SubmitterType":"Account",
                "JobType":"SQL",
                "Progress":"{}",
                "EngineType":"Presto",
                "Conf":"{\"las.execute.queuename\":\"benchmark\",\"tqs.spark.runtime.version\":\"spark3\"}",
                "DriverLogEnabled":true,
                "FinishTime":"2023-08-22 17:32:19",
                "Json":"select 1",
                "Status":"Completed"
            }
            """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_failed_sql_job():
    return json.loads(r"""
            {
                "SqlType":"DQL",
                "Id":"123456",
                "Name":"查询 01-17 10:29",
                "DataleapTaskId":"",
                "DurationStage":3,
                "Duration":"1827:29:08",
                "SubmitLogEnabled":true,
                "QueueRole":"none",
                "Submitter":"LasQATeam",
                "TrackingUrlEnabled":true,
                "Origin":"LAS Web UI",
                "QueueName":"benchmark",
                "StartTime":"2023-06-07 14:03:11",
                "SubmitterType":"Account",
                "JobType":"SQL",
                "Progress":"{}",
                "EngineType":"Presto",
                "Conf":"{\"las.execute.queuename\":\"benchmark\",\"tqs.spark.runtime.version\":\"spark3\"}",
                "DriverLogEnabled":true,
                "FinishTime":"2023-08-22 17:32:19",
                "Json":"select 1",
                "Status":"Failed"
            }
            """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_processing_sql_job():
    return json.loads(r"""
            {
                "SqlType":"DML",
                "Id":"123456",
                "Name":"查询 01-17 10:29",
                "DataleapTaskId":"",
                "DurationStage":3,
                "Duration":"1827:29:08",
                "SubmitLogEnabled":true,
                "QueueRole":"none",
                "Submitter":"LasQATeam",
                "TrackingUrlEnabled":true,
                "Origin":"LAS Web UI",
                "QueueName":"benchmark",
                "StartTime":"2023-06-07 14:03:11",
                "SubmitterType":"Account",
                "JobType":"SQL",
                "Progress":"{}",
                "EngineType":"Presto",
                "Conf":"{\"las.execute.queuename\":\"benchmark\",\"tqs.spark.runtime.version\":\"spark3\"}",
                "DriverLogEnabled":true,
                "Json":"insert into test_scm.test_tbl select 1",
                "Status":"Processing"
            }
            """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_cancelled_sql_job():
    return json.loads(r"""
            {
                "SqlType":"DML",
                "Id":"123456",
                "Name":"查询 01-17 10:29",
                "DataleapTaskId":"",
                "DurationStage":3,
                "Duration":"1827:29:08",
                "SubmitLogEnabled":true,
                "QueueRole":"none",
                "Submitter":"LasQATeam",
                "TrackingUrlEnabled":true,
                "Origin":"LAS Web UI",
                "QueueName":"benchmark",
                "StartTime":"2023-06-07 14:03:11",
                "SubmitterType":"Account",
                "JobType":"SQL",
                "Progress":"{}",
                "EngineType":"Presto",
                "Conf":"{\"las.execute.queuename\":\"benchmark\",\"tqs.spark.runtime.version\":\"spark3\"}",
                "DriverLogEnabled":true,
                "FinishTime":"2023-08-22 17:32:19",
                "Json":"insert into test_scm.test_tbl select 1",
                "Status":"Cancelled"
            }
            """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_fetch_result_by_batch_single_page():
    return json.loads(r"""
        {
            "rows":[
                ["1","aaaa","1","20230530"],
                ["2","bbbb","2","20230530"]
            ],
            "position":77,
            "isFinished":true
        }
    """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_operation_success():
    return json.loads(r"""{"Success": true}""", object_hook=lambda d: SimpleNamespace(**d))


def _mock_operation_failed():
    return json.loads(r"""{"Success": false}""", object_hook=lambda d: SimpleNamespace(**d))


def _mock_result_schema_with_all_data_types():
    return json.loads(r"""
        [["col1","int"],["col2","BIGINT"],["col3","DOUBLE"],
        ["col4","DECIMAL(10,0)"],["col5","varchar"],["col6","VARBINARY"],
        ["col7","BOOLEAN"],["col8","DATE"],["col9","TIMESTAMP"],
        ["col10","ARRAY(varchar)"],["col11","MAP(varchar,varchar)"],
        ["date","varchar"]]
    """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_result_schema_with_all_data_types():
    return json.loads(r"""
        [["col1","int"],["col2","BIGINT"],["col3","DOUBLE"],
        ["col4","DECIMAL(10,0)"],["col5","varchar"],["col6","VARBINARY"],
        ["col7","BOOLEAN"],["col8","DATE"],["col9","TIMESTAMP"],
        ["col10","ARRAY(varchar)"],["col11","MAP(varchar,varchar)"],
        ["date","varchar"]]
    """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_result_schema_with_unexpected_data_types():
    return json.loads(r"""
        [["col1","int"],["col2","BIGINT"],["col3","DOUBLE"],
        ["col4","DECIMAL(10,0)"],["col5","varchar"],["col6","VARBINARY"],
        ["col7","BOOLEAN"],["col8","DATE"],["col9","TIMESTAMP"],
        ["col10","ARRAY(varchar)"],["col11","MAP(varchar,varchar)"],
        ["col12", "asdqasascxasdazx"]]
    """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_fetch_result_for_non_tail_batch():
    return json.loads(r"""
        {
            "rows":[
                [
                    "123",
                    "456789",
                    "3.14",
                    "42",
                    "Sample string",
                    "binary data",
                    "true",
                    "2021-09-05",
                    "2021-09-05 12:34:56.000000",
                    "[\"item1\",\"item2\",\"item3\"]",
                    "{\"key1\":\"value1\",\"key2\":\"value2\"}",
                    "20230905"
                ]
            ],
            "position":281,
            "isFinished":false
        }
    """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_fetch_result_for_tail_batch():
    return json.loads(r"""
        {
            "rows":[
                [
                    "123",
                    "456789",
                    "3.14",
                    "42",
                    "Sample string",
                    "binary data",
                    "true",
                    "2021-09-05",
                    "2021-09-05 12:34:56.000000",
                    "[\"item1\",\"item2\",\"item3\"]",
                    "{\"key1\":\"value1\",\"key2\":\"value2\"}",
                    "20230905"
                ]
            ],
            "position":281,
            "isFinished": true
        }
    """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_pre_create_resource():
    return json.loads(r"""
        {
            "AccessKeyId":"AK",
            "SecretAccessKey":"SK",
            "SessionToken":"STS token",
            "TOSBucketName":"bucket",
            "TOSObjectKey":"object key",
            "Region":"region",
            "EndPoint":"endpoint"
        }
    """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_create_resource():
    return json.loads(r"""
        {
            "AccessKeyId":"AK",
            "SecretAccessKey":"SK",
            "SessionToken":"STS token",
            "TOSBucketName":"bucket",
            "TOSObjectKey":"object key",
            "Region":"region",
            "EndPoint":"endpoint"
        }
    """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_list_resource_empty():
    return json.loads(r"""
        {"Result": {
            "Limit":10,
            "Offset":1,
            "Total":0,
            "JobList":[]
        }}
    """, object_hook=lambda d: SimpleNamespace(**d))


def _mock_list_resource_non_empty():
    return json.loads(r"""
        {"Result": {
            "Limit":10,
            "Offset":1,
            "Total":1,
            "JobList":[
                {
                    "Id":"1",
                    "CreateTime":"2022-03-25 13:26:47",
                    "Name":"resource_name",
                    "Owner":"test-user",
                    "Type":"1",
                    "Description":"test",
                    "AllowDeletion":true,
                    "Permission":"Admin"
                }]
        }}
    """, object_hook=lambda d: SimpleNamespace(**d))
